from django.db import models

# Create your models here.
class college(models.Model):
    clg_id =models.AutoField(primary_key=True)
    clg_name=models.CharField(max_length=100)
    

class student(models.Model):
    stu_id=models.AutoField(primary_key=True)
    stu_name=models.CharField(max_length=100)
    dept=models.CharField(max_length=200)
    
    