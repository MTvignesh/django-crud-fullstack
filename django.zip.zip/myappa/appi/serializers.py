from rest_framework import serializers
from appi.models import college,student

class collegeserializer(serializers.ModelSerializer):
    class Meta:
        model=college
        fields='__all__'
        
class studentserializer(serializers.ModelSerializer):
    class Meta:
        model=student
        fields='__all__'