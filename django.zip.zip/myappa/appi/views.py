
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from django.http.response import JsonResponse
from appi.models import college

from  appi.serializers import collegeserializer


@csrf_exempt
def clg_api(request,id=0):
    if request.method =='GET':
        College = college.objects.all()
        clg_serializer =collegeserializer(College,many=True)
        return JsonResponse(clg_serializer.data,safe=False)
    elif request.method=='POST':
        clg_data = JSONParser().parse(request)
        clg_serializer=collegeserializer(data=clg_data)
        if clg_serializer.is_valid():
            clg_serializer.save()
            return JsonResponse("added sucessfully",safe=False)
    elif request.method=='PUT':
        clg_data =JSONParser().parse(request)
        clg=college.objects.get(clg_id=clg_data['clg_id'])
        clg_serializer=collegeserializer(clg,data=clg_data)
        if clg_serializer.is_valid():
            clg_serializer.save()
            return JsonResponse("updated sucessfully",safe=False)
        return JsonResponse("failed")   
    elif request.method=='DELETE': 
       
        College=college.objects.get(clg_id=id)
        College.delete()
        return JsonResponse('deleted ',safe=False)