from django.urls import path
from appi import views

urlpatterns=[
    path(r'',views.clg_api),
    path(r'/[int:pk]',views.clg_api)
]